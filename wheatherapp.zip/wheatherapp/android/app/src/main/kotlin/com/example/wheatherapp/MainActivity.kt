package com.example.wheatherapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
